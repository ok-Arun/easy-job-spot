# Easy Job Spot

A job listing platform built with React, TypeScript, Vite, and Tailwind CSS.
